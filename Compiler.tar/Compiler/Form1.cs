﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace Compiler
{
    public class Token
    {
        public string Type { get; set; }
        public string Value { get; set; }

        public Token(string type, string value)
        {
            Type = type;
            Value = value;
        }
    }

    public class Lexer
    {
        private string[] keywords = { "int", "float", "if", "else", "while", "return" };

        private bool IsKeyword(string word)
        {
            for (int i = 0; i < keywords.Length; i++)
                if (keywords[i] == word)
                    return true;

            return false;
        }

        private bool IsLetter(char c)
        {
            return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_';
        }

        private bool IsDigit(char c)
        {
            return c >= '0' && c <= '9';
        }

        public List<Token> Analyze(string input)
        {
            List<Token> tokens = new List<Token>();
            int i = 0;

            while (i < input.Length)
            {
                char c = input[i];

                if (c == ' ' || c == '\t' || c == '\n' || c == '\r')
                {
                    i++;
                    continue;
                }

                if (IsLetter(c))
                {
                    string word = "";

                    while (i < input.Length && (IsLetter(input[i]) || IsDigit(input[i])))
                    {
                        word += input[i];
                        i++;
                    }

                    if (IsKeyword(word))
                        tokens.Add(new Token("Keyword", word));
                    else
                        tokens.Add(new Token("Identifier", word));

                    continue;
                }

                if (IsDigit(c))
                {
                    string number = "";

                    while (i < input.Length && IsDigit(input[i]))
                    {
                        number += input[i];
                        i++;
                    }

                    tokens.Add(new Token("Number", number));
                    continue;
                }

                if (c == '+' || c == '-' || c == '*' || c == '/' ||
                    c == '=' || c == '<' || c == '>')
                {
                    tokens.Add(new Token("Operator", c.ToString()));
                    i++;
                    continue;
                }

                if (c == ';' || c == ',' || c == '(' || c == ')' ||
                    c == '{' || c == '}')
                {
                    tokens.Add(new Token("Symbol", c.ToString()));
                    i++;
                    continue;
                }

                tokens.Add(new Token("Unknown", c.ToString()));
                i++;
            }

            return tokens;
        }
    }

    public partial class Form1 : Form
    {
        private TextBox txtInput;
        private Button btnAnalyze;
        private DataGridView grid;
        private Label title;

        private Lexer lexer = new Lexer();

        public Form1()
        {
            InitializeUI();
        }

        private void InitializeUI()
        {
            this.Text = "Compiler Project - Lexical Analyzer";
            this.Size = new Size(900, 600);
            this.BackColor = Color.FromArgb(30, 30, 30);
            this.StartPosition = FormStartPosition.CenterScreen;

            title = new Label();
            title.Text = "Lexical Analyzer";
            title.ForeColor = Color.White;
            title.Font = new Font("Segoe UI", 18, FontStyle.Bold);
            title.Location = new Point(20, 10);
            title.AutoSize = true;

            txtInput = new TextBox();
            txtInput.Multiline = true;
            txtInput.Size = new Size(400, 400);
            txtInput.Location = new Point(20, 60);
            txtInput.BackColor = Color.FromArgb(45, 45, 48);
            txtInput.ForeColor = Color.White;
            txtInput.Font = new Font("Consolas", 11);

            btnAnalyze = new Button();
            btnAnalyze.Text = "Analyze";
            btnAnalyze.Size = new Size(150, 40);
            btnAnalyze.Location = new Point(20, 480);
            btnAnalyze.BackColor = Color.FromArgb(0, 122, 204);
            btnAnalyze.ForeColor = Color.White;
            btnAnalyze.FlatStyle = FlatStyle.Flat;
            btnAnalyze.Click += BtnAnalyze_Click;

            grid = new DataGridView();
            grid.Location = new Point(450, 60);
            grid.Size = new Size(400, 460);

            grid.BackgroundColor = Color.FromArgb(45, 45, 48);
            grid.ForeColor = Color.White;
            grid.EnableHeadersVisualStyles = false;

            grid.ColumnHeadersDefaultCellStyle.BackColor = Color.FromArgb(28, 28, 28);
            grid.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;

            grid.DefaultCellStyle.BackColor = Color.FromArgb(45, 45, 48);
            grid.DefaultCellStyle.ForeColor = Color.White;

            grid.RowHeadersVisible = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.BorderStyle = BorderStyle.None;

            grid.Columns.Add("Type", "Token Type");
            grid.Columns.Add("Value", "Value");

            this.Controls.Add(title);
            this.Controls.Add(txtInput);
            this.Controls.Add(btnAnalyze);
            this.Controls.Add(grid);
        }

        private void BtnAnalyze_Click(object sender, EventArgs e)
        {
            grid.Rows.Clear();

            List<Token> tokens = lexer.Analyze(txtInput.Text);

            foreach (Token t in tokens)
                grid.Rows.Add(t.Type, t.Value);

            grid.ClearSelection();
        }
    }
}